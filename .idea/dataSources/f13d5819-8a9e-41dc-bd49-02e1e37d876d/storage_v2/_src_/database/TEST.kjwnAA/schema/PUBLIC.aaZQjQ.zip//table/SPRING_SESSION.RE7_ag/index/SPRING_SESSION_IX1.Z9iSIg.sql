create unique index SPRING_SESSION_IX1
    on SPRING_SESSION (SESSION_ID);

